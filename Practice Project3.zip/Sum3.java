import java.util.Scanner;
class Sum3{
	public static void main(String[] args)
	{
		int l,r,sum=0;
		System.out.println("Enter Range:");
		Scanner sc=new Scanner(System.in);
		l=sc.nextInt();
		r=sc.nextInt();
		for(int i=l;i<=r;i++)
		{
			sum=sum+i;
		}
		System.out.println("sum from range "+l+" to "+r+": "+sum);
	}
}