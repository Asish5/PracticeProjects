function msg(){


    var tag="<form name='f1'>username<input type='text' name='user'><br>password<input type='password' name='pwd'><br></form>";
    document.getElementById("place").innerHTML=tag
    }
    