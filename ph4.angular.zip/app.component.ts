import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demoproject';
  heading="Session on Angular"
  a=33
  b="true"
  c=4.5555
  ishidden=false
  isdisabled=false
  isactive=false
 active:object=
 {
  color:'white',
  background:'grey'
 }
 count=0;
increment(){this.count+=1;}
decrement(){this.count-=1;}
m="hi,all"
activated!:object;
active1(){
 this.activated={ color:'white',
  background:'grey'}
}
name=""
fav_language=""
score=0;
ans=""
update(e:any){
  this.ans=e.target.value;
if(this.ans===("Banglore")){
  this.score++;
}
}

show(){
  return true;
}

shows=true
textdata="hi,welcome"
showsc=false

showed=false

num1=3
num2=4
opr="+"

mobilebrand=[{"id":1,"name":"karthik","mobile":"samsung"},{"id":2,"name":"ajay","mobile":"iphone"}]
salary=10000

date=new Date()
person={"name":"john","age":30}
wishdata="Good morning"
person1={"name":"ARUN","gender":"m"}

}
