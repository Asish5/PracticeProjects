package com.example;

public class Prime {
	public String validate(int a) {
		for(int i=2;i<=a/2;i++)
			if(a%i==0)
				return "not prime";
         return "prime";
}
}