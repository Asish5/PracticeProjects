package com.example;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PrimeTest {
	@Test
	public void test1() {
		Prime valid=new Prime();
		
	//	 expected value  actual value
		  assertEquals("not prime",valid.validate(8));
	}

	
	@Test
	public void test2() {
		Prime valid=new Prime();
		
	//	 expected value  actual value
		  assertEquals("prime",valid.validate(7));
	}
}
