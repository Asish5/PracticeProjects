package com.example;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
       Student s=ac.getBean(Student.class);
       StudentDao dao=ac.getBean(StudentDao.class);
       Scanner sc=new Scanner(System.in);
       System.out.println("enter the id value ");
       s.setId(sc.nextInt());
       System.out.println("enter the name value");
       s.setName(sc.next());
       System.out.println("enter the email value");
       s.setEmail(sc.next());
       int row=dao.insert(s);
       if(row>0) {
    	   System.out.println("inserted successfully ");
       }
       else {
    	   System.out.println("insertion failed ");
       }
       
       
       List<Student> list=dao.getallstudents();
       for(Student ss:list) {
    	   System.out.println(ss);
       }
       System.out.println("enter the id value to be deleted");
       Student s1=ac.getBean(Student.class);
       s.setId(sc.nextInt());
       List<Student> list1=dao.getallstudents();
       for(Student ss:list1) {
    	   System.out.println(ss);
       }
     }
    
}

